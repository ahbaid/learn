#!/usr/bin/env python

a=1

if a:
   def fn1(): print('true')
else:
   def fn1(): print('false')

fn1()
