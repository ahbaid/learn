#!/usr/bin/env python

import sys
print(sys.version)
print(sys.version_info)
