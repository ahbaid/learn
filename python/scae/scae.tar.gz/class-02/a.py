#!/usr/bin/env python
abc='abcdefghijklmnopqrstuvwxyz'
print (__name__)
