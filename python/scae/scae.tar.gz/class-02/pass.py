#!/usr/bin/env python

a=1

# pass is a python noop operation and continues to the next statement
if (a>0):
   pass
else:
   pass
