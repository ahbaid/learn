#!/usr/bin/env python

a=1
print("a =",a)
a+=2
print("a+=2 -> ",a)

