#!/usr/bin/env python

s1=set([1,2,3])
print(s1)
print(type(s1))
print(1 in s1)

s2={1,3,5}
print(s2)
print(type(s2))
print(4 in s2)
