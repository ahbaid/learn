#!/usr/bin/env python

print('IMMUTABLE TYPES: Numbers, Strings, Tuples')
print('MUTABLE TYPES: Lists, Dictionaries, Sets, File, Boolean (non-exhaustive)')
