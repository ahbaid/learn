#!/usr/bin/env python
l=['a','b','c','d','e','f']
print("List l: ",l)

print("l[0:2] prints pos 0 to pos 1 -> ",l[0:2])
print("l[2:4] prints pos 2 to pos 3 -> ",l[2:4])
print("l[:] prints complete list -> ",l[:])

