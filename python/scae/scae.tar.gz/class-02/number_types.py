#!/usr/bin/env python

#decimal 15
x=15
print('dec 15: ',x)

#octal 15 (0o prefix)
x=0o17
print('oct 0o17: ',x)

#hex 15 (0x prefix)
x=0xf
print('hex 0xf: ',x)
dir(x)
