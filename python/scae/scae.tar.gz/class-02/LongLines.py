#!/usr/bin/env python

a="This is a lon\
g line"
print("a: ",a)


b="This is string 1"\
" and string 2"
print("b: ",b)

c=[1,2,3,
4,5,6]
print("c: ",c)

d=1+2+3+4+\
5+6
print("d: ",d)

e=(1+2+3+4
+5+6)
print("e: ",e)
