#!/usr/bin/env python

def double(x):
   """ double(x) -> x """
   return x*2
