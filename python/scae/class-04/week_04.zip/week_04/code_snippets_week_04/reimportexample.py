#!/usr/bin/env python
# encoding: utf-8
"""
reimportexample.py

Sample code for SCAE Introduction to Python class
"""

# To reimport the module, you need to:
#    from imp import reload
#    reload(<modulename>)

def printHello():
    print("Hello")

if __name__ == '__main__':
    printHello()
