#!/usr/bin/env python
# encoding: utf-8
"""
example_4_3.py

Sample code for SCAE Introduction to Python class
"""

# import sys
# import os


def main():
    pass

if __name__ == '__main__':
    main()

