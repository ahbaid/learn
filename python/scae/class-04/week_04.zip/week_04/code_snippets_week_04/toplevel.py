#!/usr/bin/env python
# encoding: utf-8
"""
toplevel.py

Sample code for SCAE Introduction to Python class
"""

import modlevel1
import sub1.sub2.sub3.modlevel3

print('Going to call modlevel1.func1')
modlevel1.func1()

print('Going to call modlevel3.func2')
sub1.sub2.sub3.modlevel3.func2()