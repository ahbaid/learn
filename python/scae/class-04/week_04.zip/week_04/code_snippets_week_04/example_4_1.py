#!/usr/bin/env python
# encoding: utf-8
"""
example_4_1.py

Sample code for SCAE Introduction to Python class
"""

import sys
import os
import re

def searchUsingStringFind(pat, filename):
    print("=== Searching using String Find ===")
    fh = open(filename)
    count = 0
    for line in fh:
        pos = line.find(pat)
        if pos != -1:
            print("found at pos %d line=%s" % (pos, line), end='')
            count += 1
    fh.close()
    print("Number of lines found: %d" % count)


def searchUsingRegex(pat, filename):
    print("=== Searching using Regex ===")
    fh = open(filename)
    count = 0
    for line in fh:
        line = line.rstrip()
        match = re.search(pat, line)
        if match:
            print("match group=%s=  line=%s" % (match.group(), line))
            count += 1
    fh.close()
    print("Number of lines found: %d" % count)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage %s <filename>" % sys.argv[0])
        sys.exit()
    
    # An example of os.path.join to create a path name
    filename = os.path.join('earthquake_data', sys.argv[1])
    
    searchUsingStringFind('5.5', filename)
    searchUsingRegex(r'5\.\d', filename)
    #searchUsingRegex(r'5\.[567]', filename)
    
