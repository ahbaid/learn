#!/usr/bin/env python
# encoding: utf-8
"""
example_4_4.py

Sample code for SCAE Introduction to Python class
"""

import sys
import os

# global var
g = 10

def func1(x):
    ''' scope test function'''
    print('globals:', globals().keys())
    print('locals at start:', locals().keys())
    y = x
    a = g
    print('locals at end:', locals().keys())
    print("y is %s" % y)
    print("a is %s" % a)