#!/usr/bin/env python
# encoding: utf-8
"""
re_test1.py

Sample code for SCAE Introduction to Python class
"""

import sys
import os
import re


def main():
    if len(sys.argv) < 2:
        print("Usage %s <filename>" % sys.argv[0])
        sys.exit()
    
    # really should be putting this in a try/except block
    
    fh =  open(sys.argv[1])
    for X in fh.readlines():
        match = re.search(r'^<a.*?>Magnitude (\d\.\d)\s(.*?)</a>$', X)
        if match:
            mag = match.group(1)
            loc = match.group(2)
            print('Magnitude %s %s' % (mag, loc))
    fh.close()
    

if __name__ == '__main__':
    main()

