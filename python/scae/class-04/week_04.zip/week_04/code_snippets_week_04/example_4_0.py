#!/usr/bin/env python
# encoding: utf-8
"""
example_4_0.py

Sample code for SCAE Introduction to Python class
"""

import sys
#import os


def main():
    pass

if __name__ == '__main__':
    if sys.argv:
        print("Number of arguments on the command line: %d" % len(sys.argv))
        print('The arguments are:')
        for X in sys.argv:
            print("\t%s" % X)
    else:
        # won't get here...
        print("No command line arguments")


