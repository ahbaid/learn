#!/usr/bin/env python
# encoding: utf-8
"""
example_4_2.py

Sample code for SCAE Introduction to Python class
"""

import re

def doSearch(pat, s, reflags, comment=""):
    print('Searching for pattern :%s: (%s)' % (pat, comment))
    match = re.search(pat, s, reflags)
    if match:
        print("match group :%s:" % match.group())
    else:
        print("No match found")
    print("")

if __name__ == '__main__':
    
    s = '''A string which
spans
3 lines'''

    print('==========================')
    print(s)
    print('==========================')
    doSearch(r'String', s, False, "No flags")
    doSearch(r'String', s, re.IGNORECASE, "Ignoring case")
    
    doSearch(r'^s.*ns', s, False, "No flags")
    doSearch(r'^s.*ns', s, re.MULTILINE, "Multiline")
    
    doSearch(r'which.*3', s, False, "No flags")
    doSearch(r'which.*3', s, re.DOTALL, "Dotall")
    
    # Use the bit-wise or operator |, to combine multiple flags
    doSearch(r'WHICH.*3', s, re.DOTALL|re.IGNORECASE, "Dotall and Ignorecase")
    
    