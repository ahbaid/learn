#!/usr/bin/env python
# encoding: utf-8
"""
mymath2.py

Sample code for SCAE Introduction to Python class
"""

_pi = 3.14159

def int_circle_area(radius):
    '''Compute the area of a circle and only return the integer part'''
    return int(_pi * (radius ** 2))

def int_square_area(side):
    '''Area of a square truncated to the nearest int'''
    return int(side ** 2)

if __name__ == '__main__':
    side = 12.3
    print("for radius %4.1f circle's area is %d" % (side, int_circle_area(side)))
    print("for side %4.1f square's area is %d" % (side, int_square_area(side)))
