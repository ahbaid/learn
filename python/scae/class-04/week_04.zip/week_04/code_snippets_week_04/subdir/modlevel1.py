#!/usr/bin/env python
# encoding: utf-8
"""
modlevel1.py

Sample code for SCAE Introduction to Python class
"""

def func1():
    """docstring for func1"""
    print("In function func1 in modlevel1")

def func2():
    """docstring for func2"""
    print("In function func2 in modlevel1")
